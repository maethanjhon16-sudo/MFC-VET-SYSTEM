import { Fragment, useEffect, useMemo, useReducer, useState } from 'react';
import type { FormEvent, ReactNode } from 'react';
import { Icon } from '../../components/ui/Icon';
import {
  completeStaffFollowUp,
  createStaffFollowUp,
  getStaffAvailability,
  getStaffAppointmentTimes,
  getStaffClinicalRecords,
  getStaffConversationMessages,
  getStaffConversations,
  getStaffFollowUps,
  getStaffDoctors,
  getStaffInventory,
  getStaffLabResults,
  getStaffOrders,
  getStaffPreferences,
  getStaffProfile,
  getStaffServices,
    createStaffClinicalRecord,
    createStaffLabResult,
    reviewStaffLabResult,
    sendStaffMessage,
    setStaffInventoryQuantity,
    setStaffServiceEnabled,
    saveStaffAvailability,
    saveStaffPreferences,
    startStaffConversation,
    updateStaffLabResult,
    updateStaffProfile,
    updateStaffOrderStatus,
  type ClinicalRecord as ApiClinicalRecord,
  type ClinicServiceSetting,
  type DoctorAvailabilityDay,
  type DoctorNotificationSettings,
  type InventoryItem,
  type LabResult as ApiLabResult,
  type StaffConversation,
  type StaffFollowUp,
  type BookingDoctor,
  type StaffMessage,
  type StaffOrder,
  type StaffProfile,
} from '../auth/api';
import { PRODUCTS, SERVICES } from '../owner/data';
import type { Product, Service } from '../owner/types';
import styles from './DoctorWorkspacePages.module.css';

export type DoctorAuxiliaryView =
  | 'records'
  | 'labs'
  | 'follow-ups'
  | 'inbox'
  | 'services'
  | 'inventory'
  | 'orders'
  | 'profile'
  | 'availability'
  | 'settings';

type Patient = {
  id: string;
  name: string;
  species: string;
  breed: string;
  age: string;
  owner: string;
  lastVisit: string;
  note: string;
};
type Appointment = {
  id: string;
  owner: string;
  pet: string;
  species: string;
  service: string;
  date: string;
  time: string;
  status: 'Confirmed' | 'Pending' | 'Completed' | 'Declined';
  reason: string;
};

type FilterKey = 'record' | 'lab' | 'follow-up' | 'service' | 'order';
type WorkspaceState = {
  query: string;
  filters: Record<FilterKey, string>;
  records: ApiClinicalRecord[];
  labResults: ApiLabResult[];
  followUps: StaffFollowUp[];
  conversations: StaffConversation[];
  messages: StaffMessage[];
  services: ClinicServiceSetting[];
  inventory: InventoryItem[];
  orders: StaffOrder[];
  profile: StaffProfile | null;
  availability: DoctorAvailabilityDay[];
  preferences: DoctorNotificationSettings | null;
  loading: boolean;
  loadError: string | null;
  serviceAvailability: Record<string, boolean>;
  stockLevels: Record<string, number>;
  activeDays: Record<string, boolean>;
  notificationSettings: DoctorNotificationSettings;
  selectedConversationId: string;
  draft: string;
  profileName: string;
  profilePhone: string;
  profileDirty: boolean;
  preferencesDirty: boolean;
  startTime: string;
  endTime: string;
  availabilityDirty: boolean;
  stockDrafts: Record<string, string>;
  stockDirty: Record<string, boolean>;
  recordFormOpen: boolean;
  labFormOpen: boolean;
  conversationFormOpen: boolean;
  saving: boolean;
  actionError: string | null;
  notice: string;
};

type WorkspaceAction =
  | {
      type: 'WORKSPACE_LOADED';
      records: ApiClinicalRecord[];
      labResults: ApiLabResult[];
      followUps: StaffFollowUp[];
      conversations: StaffConversation[];
      services: ClinicServiceSetting[];
      inventory: InventoryItem[];
      orders: StaffOrder[];
      profile: StaffProfile;
      availability: DoctorAvailabilityDay[];
      preferences: DoctorNotificationSettings;
    }
  | { type: 'WORKSPACE_FAILED'; message: string }
  | { type: 'SET_QUERY'; value: string }
  | { type: 'SET_FILTER'; key: FilterKey; value: string }
  | { type: 'TOGGLE_DAY'; day: string }
  | { type: 'TOGGLE_SETTING'; key: keyof DoctorNotificationSettings }
  | { type: 'RECORD_CREATED'; record: ApiClinicalRecord }
  | { type: 'LAB_CREATED'; labResult: ApiLabResult }
  | { type: 'LAB_UPDATED'; labResult: ApiLabResult }
  | { type: 'LAB_REVIEWED'; labResult: Pick<ApiLabResult, 'id' | 'status' | 'reviewedAt'> }
  | { type: 'FOLLOW_UP_COMPLETED'; id: string }
  | { type: 'FOLLOW_UP_CREATED'; followUp: StaffFollowUp }
  | { type: 'FOLLOW_UPS_RELOADED'; followUps: StaffFollowUp[] }
  | { type: 'SERVICE_UPDATED'; service: ClinicServiceSetting }
  | { type: 'INVENTORY_UPDATED'; item: InventoryItem }
  | { type: 'SET_STOCK_DRAFT'; productId: string; value: string }
  | { type: 'ORDER_UPDATED'; order: Pick<StaffOrder, 'id' | 'status'> }
  | { type: 'AVAILABILITY_UPDATED'; days: DoctorAvailabilityDay[] }
  | { type: 'PREFERENCES_UPDATED'; preferences: DoctorNotificationSettings }
  | { type: 'PROFILE_UPDATED'; profile: StaffProfile }
  | { type: 'CONVERSATIONS_UPDATED'; conversations: StaffConversation[] }
  | { type: 'SET_MESSAGES'; messages: StaffMessage[] }
  | { type: 'MESSAGE_SENT'; message: StaffMessage }
  | { type: 'SELECT_CONVERSATION'; id: string }
  | { type: 'SET_DRAFT'; value: string }
  | { type: 'SET_PROFILE_NAME'; value: string }
  | { type: 'SET_PROFILE_PHONE'; value: string }
  | { type: 'SET_START_TIME'; value: string }
  | { type: 'SET_END_TIME'; value: string }
  | { type: 'TOGGLE_RECORD_FORM' }
  | { type: 'TOGGLE_LAB_FORM' }
  | { type: 'TOGGLE_CONVERSATION_FORM' }
  | { type: 'SAVING'; value: boolean }
  | { type: 'ACTION_FAILED'; message: string }
  | { type: 'SET_NOTICE'; value: string };

type ClinicalRecord = {
  id: string;
  patientId: string;
  patient: string;
  owner: string;
  type: string;
  summary: string;
  date: string;
  status: 'Final' | 'Profile only';
};

const WEEKDAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const WEEKDAY_NUMBERS = [1, 2, 3, 4, 5, 6, 0];
const ORDER_FILTERS = ['All', 'Pending', 'Confirmed', 'Preparing', 'Ready for pickup', 'Out for delivery', 'Completed', 'Cancelled'];
const ORDER_STATUSES: StaffOrder['status'][] = ['pending', 'confirmed', 'preparing', 'ready_for_pickup', 'out_for_delivery', 'completed', 'cancelled'];
function orderStatusLabel(status: StaffOrder['status']): string {
  return status.replaceAll('_', ' ').replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function isOrderStatus(value: string): value is StaffOrder['status'] {
  return ORDER_STATUSES.some((status) => status === value);
}
const RECORD_FILTERS = ['All records', 'Patient profile', 'Consultation', 'Vaccination', 'Procedure', 'Lab notes'];
const LAB_FILTERS = ['All', 'Pending', 'In lab', 'Ready', 'Reviewed'];
const FOLLOW_UP_FILTERS = ['All', 'Medication', 'Awaiting owner', 'Overdue', 'Due soon', 'Scheduled'];

function createInitialState(): WorkspaceState {
  return {
    query: '',
    filters: { record: 'All records', lab: 'All', 'follow-up': 'All', service: 'All', order: 'All' },
    records: [],
    labResults: [],
    followUps: [],
    conversations: [],
    messages: [],
    services: [],
    inventory: [],
    orders: [],
    profile: null,
    availability: [],
    preferences: null,
    loading: true,
    loadError: null,
    serviceAvailability: {},
    stockLevels: {},
    activeDays: Object.fromEntries(WEEKDAYS.map((_, index) => [String(index), false])),
    notificationSettings: { appointmentRequests: true, followUpReminders: true, labResults: true, inventoryAlerts: false },
    selectedConversationId: '',
    draft: '',
    profileName: '',
    profilePhone: '',
    profileDirty: false,
    preferencesDirty: false,
    startTime: '08:00',
    endTime: '18:00',
    availabilityDirty: false,
    stockDrafts: {},
    stockDirty: {},
    recordFormOpen: false,
    labFormOpen: false,
    conversationFormOpen: false,
    saving: false,
    actionError: null,
    notice: '',
  };
}

function workspaceReducer(state: WorkspaceState, action: WorkspaceAction): WorkspaceState {
  switch (action.type) {
    case 'WORKSPACE_LOADED':
      return {
        ...state,
        records: action.records,
        labResults: action.labResults,
        followUps: action.followUps,
        conversations: action.conversations,
        services: action.services,
        inventory: action.inventory,
        orders: action.orders,
        profile: action.profile,
        availability: action.availability,
        preferences: action.preferences,
        selectedConversationId: state.selectedConversationId || action.conversations[0]?.id || '',
        profileName: state.profileDirty ? state.profileName : action.profile.fullName,
        profilePhone: state.profileDirty ? state.profilePhone : action.profile.phone,
        loading: false,
        loadError: null,
        serviceAvailability: Object.fromEntries(action.services.map((service) => [service.serviceId, service.isEnabled])),
        stockLevels: Object.fromEntries(action.inventory.map((item) => [item.productId, item.quantity])),
        stockDrafts: Object.fromEntries(action.inventory.map((item) => [
          item.productId,
          state.stockDirty[item.productId] ? state.stockDrafts[item.productId] ?? String(item.quantity) : String(item.quantity),
        ])),
        activeDays: state.availabilityDirty
          ? state.activeDays
          : Object.fromEntries(action.availability.map((day) => [String(day.weekday), day.isAvailable])),
        notificationSettings: state.preferencesDirty ? state.notificationSettings : action.preferences,
        startTime: state.availabilityDirty ? state.startTime : action.availability[0]?.startsAt.slice(0, 5) ?? '08:00',
        endTime: state.availabilityDirty ? state.endTime : action.availability[0]?.endsAt.slice(0, 5) ?? '18:00',
      };
    case 'WORKSPACE_FAILED':
      return { ...state, loading: false, loadError: action.message };
    case 'SET_QUERY':
      return { ...state, query: action.value };
    case 'SET_FILTER':
      return { ...state, filters: { ...state.filters, [action.key]: action.value } };
    case 'RECORD_CREATED':
      return { ...state, records: [action.record, ...state.records], recordFormOpen: false, saving: false, actionError: null, notice: 'Clinical record saved.' };
    case 'LAB_CREATED':
      return { ...state, labResults: [action.labResult, ...state.labResults], labFormOpen: false, saving: false, actionError: null, notice: 'Lab request saved.' };
    case 'LAB_UPDATED':
      return { ...state, labResults: state.labResults.map((item) => item.id === action.labResult.id ? action.labResult : item), saving: false, actionError: null, notice: 'Lab result updated.' };
    case 'LAB_REVIEWED':
      return { ...state, labResults: state.labResults.map((item) => item.id === action.labResult.id ? { ...item, ...action.labResult } : item), saving: false, actionError: null, notice: 'Lab result marked reviewed.' };
    case 'FOLLOW_UP_COMPLETED':
      return { ...state, followUps: state.followUps.filter((item) => item.id !== action.id), saving: false, actionError: null, notice: 'Follow-up marked complete.' };
    case 'FOLLOW_UP_CREATED':
      return { ...state, followUps: [action.followUp, ...state.followUps], saving: false, actionError: null, notice: 'Follow-up saved and shared with the pet owner.' };
    case 'FOLLOW_UPS_RELOADED':
      return { ...state, followUps: action.followUps, saving: false, actionError: null, notice: 'Follow-up saved and shared with the pet owner.' };
    case 'SERVICE_UPDATED':
      return { ...state, services: state.services.map((item) => item.serviceId === action.service.serviceId ? action.service : item), serviceAvailability: { ...state.serviceAvailability, [action.service.serviceId]: action.service.isEnabled }, saving: false, actionError: null, notice: 'Service availability saved.' };
    case 'INVENTORY_UPDATED':
      return {
        ...state,
        inventory: [...state.inventory.filter((item) => item.productId !== action.item.productId), action.item],
        stockLevels: { ...state.stockLevels, [action.item.productId]: action.item.quantity },
        stockDrafts: { ...state.stockDrafts, [action.item.productId]: String(action.item.quantity) },
        stockDirty: { ...state.stockDirty, [action.item.productId]: false },
        saving: false,
        actionError: null,
        notice: 'Inventory quantity saved.',
      };
    case 'SET_STOCK_DRAFT':
      return {
        ...state,
        stockDrafts: { ...state.stockDrafts, [action.productId]: action.value },
        stockDirty: { ...state.stockDirty, [action.productId]: true },
      };
    case 'ORDER_UPDATED':
      return { ...state, orders: state.orders.map((item) => item.id === action.order.id ? { ...item, status: action.order.status } : item), saving: false, actionError: null, notice: 'Order status updated.' };
    case 'AVAILABILITY_UPDATED':
      return { ...state, availability: action.days, activeDays: Object.fromEntries(action.days.map((day) => [String(day.weekday), day.isAvailable])), availabilityDirty: false, saving: false, actionError: null, notice: 'Availability saved.' };
    case 'PREFERENCES_UPDATED':
      return { ...state, preferences: action.preferences, notificationSettings: action.preferences, preferencesDirty: false, saving: false, actionError: null, notice: 'Notification preferences saved.' };
    case 'PROFILE_UPDATED':
      return { ...state, profile: action.profile, profileName: action.profile.fullName, profilePhone: action.profile.phone, profileDirty: false, saving: false, actionError: null, notice: 'Profile saved.' };
    case 'SET_MESSAGES':
      return { ...state, messages: action.messages };
    case 'CONVERSATIONS_UPDATED':
      return { ...state, conversations: action.conversations, conversationFormOpen: false, saving: false, actionError: null };
    case 'MESSAGE_SENT':
      return { ...state, messages: [...state.messages, action.message], draft: '', saving: false, actionError: null, notice: 'Message sent.' };
    case 'TOGGLE_DAY':
      return { ...state, activeDays: { ...state.activeDays, [action.day]: !state.activeDays[action.day] }, availabilityDirty: true };
    case 'TOGGLE_SETTING':
      return { ...state, notificationSettings: { ...state.notificationSettings, [action.key]: !state.notificationSettings[action.key] }, preferencesDirty: true };
    case 'SELECT_CONVERSATION':
      return { ...state, selectedConversationId: action.id, messages: [] };
    case 'SET_DRAFT':
      return { ...state, draft: action.value };
    case 'SET_PROFILE_NAME':
      return { ...state, profileName: action.value, profileDirty: true };
    case 'SET_PROFILE_PHONE':
      return { ...state, profilePhone: action.value, profileDirty: true };
    case 'SET_START_TIME':
      return { ...state, startTime: action.value, availabilityDirty: true };
    case 'SET_END_TIME':
      return { ...state, endTime: action.value, availabilityDirty: true };
    case 'TOGGLE_RECORD_FORM':
      return { ...state, recordFormOpen: !state.recordFormOpen, actionError: null };
    case 'TOGGLE_LAB_FORM':
      return { ...state, labFormOpen: !state.labFormOpen, actionError: null };
    case 'TOGGLE_CONVERSATION_FORM':
      return { ...state, conversationFormOpen: !state.conversationFormOpen, actionError: null };
    case 'SAVING':
      return { ...state, saving: action.value, actionError: null };
    case 'ACTION_FAILED':
      return { ...state, saving: false, actionError: action.message };
    case 'SET_NOTICE':
      return { ...state, notice: action.value };
    default:
      return state;
  }
}

function formatPeso(value: number): string {
  return `₱${Math.round(value).toLocaleString('en-PH')}`;
}

function manilaDate(offsetDays = 0): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  const date = new Date(`${values.year}-${values.month}-${values.day}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + offsetDays);
  return date.toISOString().slice(0, 10);
}

function manilaDateTimeLocal(): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Manila',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(new Date());
  const values = Object.fromEntries(parts.map(({ type, value }) => [type, value]));
  return `${values.year}-${values.month}-${values.day}T${values.hour}:${values.minute}`;
}

function formatManilaDateTime(value: string): string {
  return new Date(value).toLocaleString('en-PH', {
    timeZone: 'Asia/Manila',
    dateStyle: 'medium',
    timeStyle: 'short',
  });
}

function exportCsv(filename: string, rows: string[][]): void {
  const csv = rows.map((row) => row.map((cell) => `"${cell.replaceAll('"', '""')}"`).join(',')).join('\n');
  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  link.download = filename;
  link.click();
  URL.revokeObjectURL(link.href);
}

function PageHeader({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children?: ReactNode }) {
  return (
    <header className={styles.pageHeader}>
      <div><p className={styles.eyebrow}>{eyebrow}</p><h1>{title}</h1><p className={styles.description}>{description}</p></div>
      {children && <div className={styles.headerActions}>{children}</div>}
    </header>
  );
}

function SearchBox({ value, onChange, placeholder }: { value: string; onChange: (value: string) => void; placeholder: string }) {
  return <label className={styles.searchBox}><Icon name="search" size={17} /><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></label>;
}

function FilterButtons({ values, selected, onSelect }: { values: string[]; selected: string; onSelect: (value: string) => void }) {
  return <div className={styles.filters} role="group" aria-label="Filter results">{values.map((value) => <button type="button" className={selected === value ? styles.filterActive : ''} key={value} onClick={() => onSelect(value)}>{value}</button>)}</div>;
}

function Status({ children }: { children: string }) {
  const statusClass = children.toLowerCase().replaceAll(' ', '');
  return <span className={`${styles.status} ${styles[statusClass] ?? ''}`}>{children}</span>;
}

export function DoctorWorkspacePages({
  view,
  doctorName,
  patients,
  appointments,
  onNavigate,
  onOpenPatient,
  onProfileUpdated,
}: {
  view: DoctorAuxiliaryView;
  doctorName: string;
  patients: Patient[];
  appointments: Appointment[];
  onNavigate: (view: 'appointments' | 'calendar' | 'patients') => void;
  onOpenPatient: (id: string) => void;
  onProfileUpdated: (name: string) => void;
}) {
  const [state, dispatch] = useReducer(workspaceReducer, undefined, createInitialState);
  const [editingLabId, setEditingLabId] = useState<string | null>(null);
  const [labStatusDraft, setLabStatusDraft] = useState<'in_lab' | 'ready'>('in_lab');
  const [labResultDraft, setLabResultDraft] = useState('');
  const [followUpFormOpen, setFollowUpFormOpen] = useState(false);
  const [followUpType, setFollowUpType] = useState<'medicine' | 'revisit'>('medicine');
  const [followUpDoctors, setFollowUpDoctors] = useState<BookingDoctor[]>([]);
  const [followUpDoctorId, setFollowUpDoctorId] = useState('');
  const [followUpServiceId, setFollowUpServiceId] = useState('consultation');
  const [followUpDate, setFollowUpDate] = useState(manilaDate());
  const [followUpTime, setFollowUpTime] = useState('');
  const [followUpTimes, setFollowUpTimes] = useState<string[]>([]);
  const [followUpTimesLoading, setFollowUpTimesLoading] = useState(false);
  const [followUpFormError, setFollowUpFormError] = useState<string | null>(null);
  const [followUpTimesError, setFollowUpTimesError] = useState<string | null>(null);
  useEffect(() => {
    let active = true;
    let loading = false;
    const refresh = async () => {
      if (loading) return;
      loading = true;
      try {
        const [records, labs, followUps, conversations, services, inventory, orders, profile, availability, preferences] = await Promise.all([
          getStaffClinicalRecords(),
          getStaffLabResults(),
          getStaffFollowUps(),
          getStaffConversations(),
          getStaffServices(),
          getStaffInventory(),
          getStaffOrders(),
          getStaffProfile(),
          getStaffAvailability(),
          getStaffPreferences(),
        ]);
        if (!active) return;
        dispatch({
          type: 'WORKSPACE_LOADED',
          records: records.records,
          labResults: labs.labResults,
          followUps: followUps.followUps,
          conversations: conversations.conversations,
          services: services.services,
          inventory: inventory.inventory,
          orders: orders.orders,
          profile: profile.profile,
          availability: availability.availability,
          preferences: preferences.preferences.notificationSettings,
        });
      } catch (error) {
        if (active) {
          dispatch({
            type: 'WORKSPACE_FAILED',
            message: error instanceof Error ? error.message : 'Could not load doctor workspace data.',
          });
        }
      } finally {
        loading = false;
      }
    };
    const refreshIfVisible = () => {
      if (document.visibilityState === 'visible' && document.hasFocus()) void refresh();
    };
    void refresh();
    const timer = window.setInterval(refreshIfVisible, 30_000);
    document.addEventListener('visibilitychange', refreshIfVisible);
    window.addEventListener('focus', refreshIfVisible);
    return () => {
      active = false;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', refreshIfVisible);
      window.removeEventListener('focus', refreshIfVisible);
    };
  }, []);
  useEffect(() => {
    if (!state.selectedConversationId) return;
    let active = true;
    getStaffConversationMessages(state.selectedConversationId).then(({ messages }) => {
      if (active) dispatch({ type: 'SET_MESSAGES', messages });
    }).catch((error: unknown) => {
      if (active) dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not load this conversation.' });
    });
    return () => { active = false; };
  }, [state.selectedConversationId]);
  useEffect(() => {
    if (!followUpFormOpen) return;
    let active = true;
    const currentDoctorId = state.profile?.id;
    getStaffDoctors().then(({ doctors }) => {
      if (!active) return;
      setFollowUpDoctors(doctors);
      if (currentDoctorId && doctors.some((doctor) => doctor.id === currentDoctorId)) {
        setFollowUpDoctorId(currentDoctorId);
      } else {
        setFollowUpDoctorId((current) => current || doctors[0]?.id || '');
      }
    }).catch((error: unknown) => {
      if (active) setFollowUpFormError(error instanceof Error ? error.message : 'Could not load clinic veterinarians.');
    });
    return () => { active = false; };
  }, [followUpFormOpen, state.profile?.id]);
  useEffect(() => {
    if (!state.services.length) return;
    const enabledIds = SERVICES.filter((service) =>
      state.services.some((setting) => setting.serviceId === service.id && setting.isEnabled),
    ).map((service) => service.id);
    if (enabledIds.length && !enabledIds.includes(followUpServiceId)) {
      setFollowUpServiceId(enabledIds[0] ?? '');
    }
  }, [followUpServiceId, state.services]);
  useEffect(() => {
    if (
      !followUpFormOpen || followUpType !== 'revisit'
      || !followUpDoctorId || !followUpDate || !followUpServiceId
    ) {
      setFollowUpTimes([]);
      setFollowUpTime('');
      setFollowUpTimesError(null);
      return;
    }
    let active = true;
    setFollowUpTimesLoading(true);
    setFollowUpTimesError(null);
    getStaffAppointmentTimes({
      date: followUpDate,
      serviceId: followUpServiceId,
      doctorId: followUpDoctorId,
    }).then(({ times }) => {
      if (!active) return;
      setFollowUpTimes(times);
      setFollowUpTime((current) => times.includes(current) ? current : times[0] ?? '');
    }).catch((error: unknown) => {
      if (!active) return;
      setFollowUpTimes([]);
      setFollowUpTime('');
      setFollowUpTimesError(error instanceof Error ? error.message : 'Could not load available revisit times.');
    }).finally(() => {
      if (active) setFollowUpTimesLoading(false);
    });
    return () => { active = false; };
  }, [followUpDate, followUpDoctorId, followUpFormOpen, followUpServiceId, followUpType]);
  useEffect(() => {
    if (state.profile && !state.profileDirty && state.profile.fullName !== doctorName) {
      onProfileUpdated(state.profile.fullName);
    }
  }, [doctorName, onProfileUpdated, state.profile, state.profileDirty]);
  const query = state.query.trim().toLowerCase();
  const todayManila = manilaDate();
  const weekManila = manilaDate(7);
  const allRecords = useMemo(() => [
    ...state.records.map((record) => ({
      id: record.id,
      patientId: record.petId,
      patient: record.petName,
      owner: record.ownerName,
      type: record.recordType,
      summary: record.summary,
      date: new Date(record.createdAt).toLocaleDateString('en-PH', { timeZone: 'Asia/Manila', month: 'short', day: 'numeric', year: 'numeric' }),
      status: 'Final' as const,
    })),
    ...patients
      .filter((patient) => !state.records.some((record) => record.petId === patient.id))
      .map((patient): ClinicalRecord => ({
        id: `profile-${patient.id}`,
        patientId: patient.id,
        patient: patient.name,
        owner: patient.owner,
        type: 'Patient profile',
        summary: 'Profile created. No clinical notes have been added yet.',
        date: patient.lastVisit,
        status: 'Profile only',
      })),
  ], [patients, state.records]);
  const filteredRecords = useMemo(() => allRecords.filter((record) => {
    const matchesText = `${record.patient} ${record.owner} ${record.type} ${record.summary}`.toLowerCase().includes(query);
    const matchesType = state.filters.record === 'All records' || record.type === state.filters.record;
    return matchesText && matchesType;
  }), [allRecords, query, state.filters.record]);
  const labRows = useMemo(() => state.labResults.map((result) => ({
    ...result,
    patient: result.petName,
    owner: result.ownerName,
    test: result.testName,
    date: new Date(result.requestedAt).toLocaleDateString('en-PH', { timeZone: 'Asia/Manila', month: 'short', day: 'numeric', year: 'numeric' }),
    expectedDate: result.expectedAt ? formatManilaDateTime(result.expectedAt) : 'Not scheduled',
    displayStatus: result.status === 'in_lab' ? 'In lab' : result.status === 'ready' ? 'Ready' : result.status === 'reviewed' ? 'Reviewed' : 'Pending',
  })).filter((result) => {
    const matchesText = `${result.patient} ${result.owner} ${result.test} ${result.reason}`.toLowerCase().includes(query);
    const matchesStatus = state.filters.lab === 'All' || result.displayStatus === state.filters.lab;
    return matchesText && matchesStatus;
  }), [query, state.filters.lab, state.labResults]);
  const followUpRows = useMemo(() => state.followUps.map((item) => ({
    ...item,
    patient: item.petName,
    owner: item.ownerName,
    reason: item.summary,
    recordDate: new Date(item.recordCreatedAt).toLocaleDateString('en-PH', {
      timeZone: 'Asia/Manila',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }),
    due: item.appointmentScheduledAt
      ? new Date(item.appointmentScheduledAt).toLocaleString('en-PH', { timeZone: 'Asia/Manila', month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' })
      : item.followUpAt
        ? new Date(`${item.followUpAt.slice(0, 10)}T12:00:00+08:00`).toLocaleDateString('en-PH', { timeZone: 'Asia/Manila', month: 'short', day: 'numeric', year: 'numeric' })
        : 'Medication plan',
    status: item.followUpType === 'medicine'
      ? 'Medication'
      : item.appointmentStatus === 'pending'
        ? 'Awaiting owner'
        : item.followUpAt && item.followUpAt.slice(0, 10) < todayManila
          ? 'Overdue'
          : item.followUpAt && item.followUpAt.slice(0, 10) <= weekManila ? 'Due soon' : 'Scheduled',
  })).filter((item) => {
    const matchesText = `${item.patient} ${item.owner} ${item.reason}`.toLowerCase().includes(query);
    const matchesStatus = state.filters['follow-up'] === 'All' || item.status === state.filters['follow-up'];
    return matchesText && matchesStatus;
  }), [query, state.filters, state.followUps, todayManila, weekManila]);
  const visibleServices = SERVICES.filter((service) => `${service.name} ${service.blurb} ${service.category}`.toLowerCase().includes(query)
    && (state.filters.service === 'All' || service.category === state.filters.service));
  const enabledFollowUpServices = SERVICES.filter((service) =>
    state.services.some((setting) => setting.serviceId === service.id && setting.isEnabled),
  );
  const visibleProducts = PRODUCTS.filter((product) => `${product.name} ${product.category}`.toLowerCase().includes(query));
  const visibleOrders = state.orders.filter((order) => `${order.id} ${order.customerName} ${order.items.map((item) => item.productName).join(' ')}`.toLowerCase().includes(query)
    && (state.filters.order === 'All' || orderStatusLabel(order.status).toLowerCase() === state.filters.order.toLowerCase()));
  const conversations = state.conversations.filter((conversation) => `${conversation.ownerName} ${conversation.petName} ${conversation.latestMessage ?? ''}`.toLowerCase().includes(query));
  const selectedConversation = state.conversations.find((conversation) => conversation.id === state.selectedConversationId);

  const saveNotice = (message: string) => dispatch({ type: 'SET_NOTICE', value: message });
  const submitRecord = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const petId = String(formData.get('petId') ?? '');
    const recordType = String(formData.get('recordType') ?? '').trim();
    const summary = String(formData.get('summary') ?? '').trim();
    if (!petId || !recordType || !summary) return;
    dispatch({ type: 'SAVING', value: true });
    try {
      const { record } = await createStaffClinicalRecord({
        petId,
        recordType,
        summary,
        diagnosis: String(formData.get('diagnosis') ?? '').trim(),
        treatment: String(formData.get('treatment') ?? '').trim(),
        followUpAt: String(formData.get('followUpAt') ?? '') || null,
      });
      dispatch({ type: 'RECORD_CREATED', record });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save this clinical record.' });
    }
  };
  const submitFollowUp = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const petId = String(formData.get('petId') ?? '');
    const summary = String(formData.get('summary') ?? '').trim();
    if (!petId || !summary) return;
    if (!followUpDoctorId) {
      setFollowUpFormError('Choose an active veterinarian for this follow-up.');
      return;
    }
    setFollowUpFormError(null);
    dispatch({ type: 'SAVING', value: true });
    try {
      let followUp: StaffFollowUp;
      if (followUpType === 'medicine') {
        ({ followUp } = await createStaffFollowUp({
          type: 'medicine',
          petId,
          doctorId: followUpDoctorId,
          summary,
          medicineName: String(formData.get('medicineName') ?? '').trim(),
          medicineDose: String(formData.get('medicineDose') ?? '').trim(),
          medicineInstructions: String(formData.get('medicineInstructions') ?? '').trim(),
        }));
      } else {
        if (!followUpTime) {
          setFollowUpFormError('Choose an available revisit time.');
          dispatch({ type: 'SAVING', value: false });
          return;
        }
        ({ followUp } = await createStaffFollowUp({
          type: 'revisit',
          petId,
          doctorId: followUpDoctorId,
          summary,
          serviceId: followUpServiceId,
          scheduledAt: new Date(`${followUpDate}T${followUpTime}:00+08:00`).toISOString(),
        }));
      }
      dispatch({ type: 'FOLLOW_UP_CREATED', followUp });
      setFollowUpFormOpen(false);
      try {
        const { followUps } = await getStaffFollowUps();
        dispatch({ type: 'FOLLOW_UPS_RELOADED', followUps });
      } catch (refreshError) {
        dispatch({
          type: 'ACTION_FAILED',
          message: `Follow-up was saved, but the list could not be refreshed: ${refreshError instanceof Error ? refreshError.message : 'try refreshing the page.'}`,
        });
      }
    } catch (error) {
      setFollowUpFormError(error instanceof Error ? error.message : 'Could not save this follow-up.');
      dispatch({ type: 'SAVING', value: false });
    }
  };
  const submitLab = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const petId = String(formData.get('petId') ?? '');
    const testName = String(formData.get('testName') ?? '').trim();
    if (!petId || !testName) return;
    dispatch({ type: 'SAVING', value: true });
    try {
      const expectedAt = String(formData.get('expectedAt') ?? '');
      if (!expectedAt) {
        dispatch({ type: 'ACTION_FAILED', message: 'Choose when the test is expected.' });
        return;
      }
      const { labResult } = await createStaffLabResult({
        petId,
        testName,
        reason: String(formData.get('reason') ?? '').trim(),
        expectedAt: new Date(`${expectedAt}:00+08:00`).toISOString(),
      });
      dispatch({ type: 'LAB_CREATED', labResult });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save this lab request.' });
    }
  };
  const beginLabEdit = (result: ApiLabResult) => {
    setEditingLabId(result.id);
    setLabStatusDraft(result.status === 'ready' ? 'ready' : 'in_lab');
    setLabResultDraft(result.resultText);
  };
  const saveLabResult = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!editingLabId) return;
    dispatch({ type: 'SAVING', value: true });
    try {
      const { labResult } = await updateStaffLabResult(editingLabId, {
        status: labStatusDraft,
        resultText: labResultDraft.trim(),
      });
      dispatch({ type: 'LAB_UPDATED', labResult });
      setEditingLabId(null);
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not update this lab result.' });
    }
  };
  const completeFollowUp = async (id: string) => {
    dispatch({ type: 'SAVING', value: true });
    try {
      await completeStaffFollowUp(id);
      dispatch({ type: 'FOLLOW_UP_COMPLETED', id });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not complete this follow-up.' });
    }
  };
  const markLabReviewed = async (id: string) => {
    dispatch({ type: 'SAVING', value: true });
    try {
      const { labResult } = await reviewStaffLabResult(id);
      dispatch({ type: 'LAB_REVIEWED', labResult });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not mark the result reviewed.' });
    }
  };
  const toggleService = async (serviceId: string) => {
    dispatch({ type: 'SAVING', value: true });
    try {
      const { service } = await setStaffServiceEnabled(serviceId, !(state.serviceAvailability[serviceId] ?? true));
      dispatch({ type: 'SERVICE_UPDATED', service });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not update this service.' });
    }
  };
  const saveStock = async (productId: string) => {
    const rawQuantity = state.stockDrafts[productId] ?? '';
    const quantity = Number(rawQuantity);
    if (rawQuantity.trim() === '' || !Number.isInteger(quantity) || quantity < 0 || quantity > 1_000_000) {
      dispatch({ type: 'ACTION_FAILED', message: 'Enter a whole-number stock quantity from 0 to 1,000,000.' });
      return;
    }
    dispatch({ type: 'SAVING', value: true });
    try {
      const { item } = await setStaffInventoryQuantity(productId, quantity);
      dispatch({ type: 'INVENTORY_UPDATED', item });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save this inventory quantity.' });
    }
  };
  const updateOrder = async (orderId: string, status: StaffOrder['status']) => {
    dispatch({ type: 'SAVING', value: true });
    try {
      const { order } = await updateStaffOrderStatus(orderId, status);
      dispatch({ type: 'ORDER_UPDATED', order });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not update this order status.' });
    }
  };
  const saveAvailability = async () => {
    dispatch({ type: 'SAVING', value: true });
    try {
      const { availability } = await saveStaffAvailability(WEEKDAYS.map((_, index) => ({
        weekday: WEEKDAY_NUMBERS[index] ?? 0,
        isAvailable: state.activeDays[String(WEEKDAY_NUMBERS[index] ?? 0)] ?? false,
        startsAt: state.startTime,
        endsAt: state.endTime,
      })));
      dispatch({ type: 'AVAILABILITY_UPDATED', days: availability });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save availability.' });
    }
  };
  const savePreferences = async () => {
    dispatch({ type: 'SAVING', value: true });
    try {
      const { preferences } = await saveStaffPreferences(state.notificationSettings);
      dispatch({ type: 'PREFERENCES_UPDATED', preferences: preferences.notificationSettings });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save preferences.' });
    }
  };
  const saveProfile = async () => {
    const fullName = state.profileName.trim();
    if (!fullName) {
      dispatch({ type: 'ACTION_FAILED', message: 'Enter your display name before saving.' });
      return;
    }
    dispatch({ type: 'SAVING', value: true });
    try {
      const { profile } = await updateStaffProfile({ fullName, phone: state.profilePhone });
      dispatch({ type: 'PROFILE_UPDATED', profile });
      onProfileUpdated(profile.fullName);
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not save your profile.' });
    }
  };
  const selectConversation = async (id: string) => {
    dispatch({ type: 'SELECT_CONVERSATION', id });
    try {
      const { messages } = await getStaffConversationMessages(id);
      dispatch({ type: 'SET_MESSAGES', messages });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not load this conversation.' });
    }
  };
  const sendMessage = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!state.selectedConversationId || !state.draft.trim()) return;
    dispatch({ type: 'SAVING', value: true });
    try {
      const { message } = await sendStaffMessage(state.selectedConversationId, state.draft.trim());
      dispatch({ type: 'MESSAGE_SENT', message });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not send this message.' });
    }
  };
  const startConversation = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    const petId = String(formData.get('petId') ?? '');
    const body = String(formData.get('body') ?? '').trim();
    if (!petId || !body) return;
    dispatch({ type: 'SAVING', value: true });
    try {
      const { conversationId, message } = await startStaffConversation({ petId, body });
      const { conversations } = await getStaffConversations();
      dispatch({ type: 'CONVERSATIONS_UPDATED', conversations });
      dispatch({ type: 'SELECT_CONVERSATION', id: conversationId });
      dispatch({ type: 'SET_MESSAGES', messages: [message] });
    } catch (error) {
      dispatch({ type: 'ACTION_FAILED', message: error instanceof Error ? error.message : 'Could not start this conversation.' });
    }
  };
  const title: { eyebrow: string; title: string; description: string } = {
    records: { eyebrow: 'CLINICAL RECORDS', title: 'Clinical records', description: 'Consultation notes, diagnoses and treatment plans across your patients.' },
    labs: { eyebrow: 'LAB RESULTS', title: 'Laboratory results', description: 'Track requested tests and review completed results.' },
    'follow-ups': { eyebrow: 'FOLLOW-UPS', title: 'Follow-up appointments', description: 'Patients who need a recheck, ordered by urgency.' },
    inbox: { eyebrow: 'INBOX', title: 'Doctor inbox', description: 'Conversations with pet owners about their care.' },
    services: { eyebrow: 'CLINIC OPERATIONS', title: 'Service management', description: 'Review the clinic services available for booking.' },
    inventory: { eyebrow: 'CLINIC OPERATIONS', title: 'Product inventory', description: 'Review product stock levels and low-stock items.' },
    orders: { eyebrow: 'CLINIC OPERATIONS', title: 'Order management', description: 'Track shop orders placed by owners.' },
    profile: { eyebrow: 'ACCOUNT', title: 'Doctor profile', description: 'Your clinic account and professional details.' },
    availability: { eyebrow: 'ACCOUNT', title: 'Availability', description: 'Your recurring schedule for appointment requests.' },
    settings: { eyebrow: 'ACCOUNT', title: 'Settings', description: 'Manage your workspace preferences.' },
  }[view];

  return (
    <section className={styles.page}>
      <PageHeader eyebrow={title.eyebrow} title={title.title} description={title.description}>
        {view === 'records' && <><button type="button" className={styles.secondaryButton} onClick={() => exportCsv('clinical-records.csv', [['Patient', 'Owner', 'Record type', 'Summary', 'Date', 'Status'], ...filteredRecords.map((record) => [record.patient, record.owner, record.type, record.summary, record.date, record.status])])}>Export</button><button type="button" className={styles.primaryButton} onClick={() => dispatch({ type: 'TOGGLE_RECORD_FORM' })}>＋ Add record</button></>}
        {view === 'labs' && <button type="button" className={styles.primaryButton} onClick={() => dispatch({ type: 'TOGGLE_LAB_FORM' })}>＋ Request test</button>}
        {view === 'follow-ups' && <button type="button" className={styles.primaryButton} onClick={() => {
          setFollowUpFormOpen((open) => !open);
          setFollowUpFormError(null);
        }}><Icon name="nav-calendar" size={17} />{followUpFormOpen ? 'Close follow-up form' : '＋ New follow-up'}</button>}
        {view === 'orders' && <button type="button" className={styles.secondaryButton} onClick={() => exportCsv('orders.csv', [['Order', 'Customer', 'Items', 'Total', 'Payment', 'Status'], ...visibleOrders.map((order) => [order.id, order.customerName, order.items.map((item) => `${item.quantity} × ${item.productName}`).join('; '), order.totalAmount, order.paymentMethod, order.status])])}>Export</button>}
      </PageHeader>
      {state.loading && <p className={styles.muted} role="status">Loading clinic data…</p>}
      {state.loadError && <p className={styles.error} role="alert">{state.loadError}<button type="button" onClick={() => window.location.reload()}>Reload</button></p>}
      {state.actionError && <p className={styles.error} role="alert">{state.actionError}</p>}
      {state.notice && <div className={styles.notice} role="status">{state.notice}<button type="button" aria-label="Dismiss message" onClick={() => saveNotice('')}>×</button></div>}

      {view === 'records' && <>
        <div className={styles.metrics}>
          <article><span>Records and profiles</span><b>{allRecords.length}</b><small>Across {patients.length} assigned patients</small></article>
          <article><span>Created this month</span><b>{state.records.filter((record) => {
            const createdAt = new Date(record.createdAt);
            const now = new Date();
            return createdAt.getMonth() === now.getMonth() && createdAt.getFullYear() === now.getFullYear();
          }).length}</b><small>Saved clinical notes</small></article>
          <article><span>Follow-ups scheduled</span><b>{state.records.filter((record) => record.followUpAt).length}</b><small>Linked to clinical records</small></article>
          <article><span>Patient profiles</span><b>{patients.length}</b><small>From the clinic database</small></article>
        </div>
        {state.recordFormOpen && <form className={styles.dataForm} onSubmit={(event) => void submitRecord(event)}>
          <label>Patient<select name="petId" required defaultValue=""><option value="" disabled>Choose a patient</option>{patients.map((patient) => <option value={patient.id} key={patient.id}>{patient.name} · {patient.owner}</option>)}</select></label>
          <label>Record type<select name="recordType" defaultValue="Consultation"><option>Consultation</option><option>Vaccination</option><option>Procedure</option><option>Lab notes</option><option>Medication</option></select></label>
          <label className={styles.wideField}>Summary<textarea name="summary" required maxLength={3000} rows={3} /></label>
          <label>Diagnosis<input name="diagnosis" maxLength={2000} /></label>
          <label>Treatment<input name="treatment" maxLength={3000} /></label>
          <label>Follow-up date<input name="followUpAt" type="date" /></label>
          <div className={styles.formActions}><button type="button" className={styles.secondaryButton} onClick={() => dispatch({ type: 'TOGGLE_RECORD_FORM' })}>Cancel</button><button type="submit" className={styles.primaryButton} disabled={state.saving}>{state.saving ? 'Saving…' : 'Save clinical record'}</button></div>
        </form>}
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search by pet, owner or diagnosis..." /></div>
        <FilterButtons values={RECORD_FILTERS} selected={state.filters.record} onSelect={(value) => dispatch({ type: 'SET_FILTER', key: 'record', value })} />
        <div className={styles.tableWrap}><table className={styles.table}>
          <thead><tr><th>Patient</th><th>Record type</th><th>Summary</th><th>Date</th><th>Status</th><th /></tr></thead>
          <tbody>{filteredRecords.map((record) => <tr key={record.id}>
            <td><button type="button" className={styles.patientLink} onClick={() => onOpenPatient(record.patientId)}><b>{record.patient}</b><small>{record.owner}</small></button></td>
            <td>{record.type}</td><td className={styles.summaryCell}>{record.summary}</td><td>{record.date}</td><td><Status>{record.status}</Status></td>
            <td><button type="button" className={styles.textButton} onClick={() => onOpenPatient(record.patientId)}>Open</button></td>
          </tr>)}{filteredRecords.length === 0 && <tr><td colSpan={6} className={styles.empty}>No records match this search.</td></tr>}</tbody>
        </table></div>
      </>}

      {view === 'labs' && <>
        <div className={styles.metrics}>
          <article><span>Tests in database</span><b>{state.labResults.length}</b><small>Across assigned patients</small></article>
          <article><span>Awaiting results</span><b>{state.labResults.filter((item) => item.status === 'pending' || item.status === 'in_lab').length}</b><small>Pending or in lab</small></article>
          <article><span>Ready to review</span><b>{state.labResults.filter((item) => item.status === 'ready').length}</b><small>Doctor sign-off</small></article>
          <article><span>Reviewed</span><b>{state.labResults.filter((item) => item.status === 'reviewed').length}</b><small>Saved review status</small></article>
        </div>
        {state.labFormOpen && <form className={styles.dataForm} onSubmit={(event) => void submitLab(event)}>
          <label>Patient<select name="petId" required defaultValue=""><option value="" disabled>Choose a patient</option>{patients.map((patient) => <option value={patient.id} key={patient.id}>{patient.name} · {patient.owner}</option>)}</select></label>
          <label>Test name<input name="testName" required maxLength={120} placeholder="e.g. CBC panel" /></label>
          <label className={styles.wideField}>Reason for test<textarea name="reason" required maxLength={2000} rows={2} placeholder="Why is this test needed?" /></label>
          <label>Expected test date and time<input name="expectedAt" type="datetime-local" min={manilaDateTimeLocal()} required /></label>
          <p className={`${styles.muted} ${styles.wideField}`}>The scheduled test will appear in your calendar and the pet owner’s medical records.</p>
          <div className={styles.formActions}><button type="button" className={styles.secondaryButton} onClick={() => dispatch({ type: 'TOGGLE_LAB_FORM' })}>Cancel</button><button type="submit" className={styles.primaryButton} disabled={state.saving}>{state.saving ? 'Saving…' : 'Create lab request'}</button></div>
        </form>}
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search patient or test..." /></div>
        <FilterButtons values={LAB_FILTERS} selected={state.filters.lab} onSelect={(value) => dispatch({ type: 'SET_FILTER', key: 'lab', value })} />
        <div className={styles.tableWrap}><table className={styles.table}>
          <thead><tr><th>Patient</th><th>Test</th><th>Reason</th><th>Requested</th><th>Expected test</th><th>Result</th><th>Status</th><th>Action</th></tr></thead>
          <tbody>{labRows.map((result) => (
            <Fragment key={result.id}>
              <tr>
                <td><button type="button" className={styles.patientLink} onClick={() => onOpenPatient(result.petId)}><b>{result.patient}</b><small>{result.owner}</small></button></td>
                <td>{result.test}</td><td className={styles.summaryCell}>{result.reason}</td><td>{result.date}</td><td>{result.expectedDate}</td><td className={styles.summaryCell}>{result.resultText || 'Not entered yet'}</td><td><Status>{result.displayStatus}</Status></td>
                <td><div className={styles.rowActions}>
                  {result.displayStatus !== 'Reviewed' && <button type="button" className={styles.textButton} disabled={state.saving} onClick={() => beginLabEdit(result)}>Update result</button>}
                  {result.displayStatus === 'Ready' && <button type="button" className={styles.textButton} disabled={state.saving} onClick={() => void markLabReviewed(result.id)}>Mark reviewed</button>}
                  {result.displayStatus === 'Reviewed' && <span className={styles.muted}>Reviewed</span>}
                </div></td>
              </tr>
              {editingLabId === result.id && <tr><td colSpan={8}>
                <form className={styles.dataForm} onSubmit={(event) => void saveLabResult(event)}>
                  <label>Status<select value={labStatusDraft} onChange={(event) => setLabStatusDraft(event.target.value as 'in_lab' | 'ready')}>
                    <option value="in_lab">In lab</option><option value="ready">Ready for review</option>
                  </select></label>
                  <label className={styles.wideField}>Result<textarea value={labResultDraft} onChange={(event) => setLabResultDraft(event.target.value)} maxLength={5000} rows={3} required={labStatusDraft === 'ready'} /></label>
                  <div className={styles.formActions}>
                    <button type="button" className={styles.secondaryButton} onClick={() => setEditingLabId(null)}>Cancel</button>
                    <button type="submit" className={styles.primaryButton} disabled={state.saving}>{state.saving ? 'Saving…' : 'Save lab update'}</button>
                  </div>
                </form>
              </td></tr>}
            </Fragment>
          ))}{labRows.length === 0 && <tr><td colSpan={8} className={styles.empty}>No lab results match this filter.</td></tr>}</tbody>
        </table></div>
      </>}

      {view === 'follow-ups' && <>
        {followUpFormOpen && <form className={styles.dataForm} onSubmit={(event) => void submitFollowUp(event)}>
          <label>Follow-up type<select value={followUpType} onChange={(event) => {
            setFollowUpType(event.target.value as 'medicine' | 'revisit');
            setFollowUpFormError(null);
          }}><option value="medicine">Medicine recommendation</option><option value="revisit">Revisit appointment</option></select></label>
          <label>Patient<select name="petId" required defaultValue=""><option value="" disabled>Choose an assigned patient</option>{patients.map((patient) => <option value={patient.id} key={patient.id}>{patient.name} · {patient.owner}</option>)}</select></label>
          {state.profile && followUpDoctors.some((doctor) => doctor.id === state.profile?.id)
            ? <label>Veterinarian<input value={state.profile.fullName} readOnly /></label>
            : <label>Veterinarian<select value={followUpDoctorId} onChange={(event) => setFollowUpDoctorId(event.target.value)} required><option value="" disabled>Choose a veterinarian</option>{followUpDoctors.map((doctor) => <option key={doctor.id} value={doctor.id}>{doctor.fullName}{doctor.specialization ? ` · ${doctor.specialization}` : ''}</option>)}</select></label>}
          <label className={styles.wideField}>{followUpType === 'medicine' ? 'Care note' : 'Reason and visit notes'}
            <textarea name="summary" required maxLength={followUpType === 'medicine' ? 2000 : 500} rows={2} placeholder={followUpType === 'medicine' ? 'Explain why this medicine is recommended.' : 'What should the veterinarian review at the revisit?'} />
          </label>
          {followUpType === 'medicine' ? <>
            <label>Medicine name<input name="medicineName" required maxLength={200} placeholder="Medicine name" /></label>
            <label>Dose<input name="medicineDose" required maxLength={200} placeholder="Dose and frequency" /></label>
            <label className={styles.wideField}>Instructions<textarea name="medicineInstructions" required maxLength={2000} rows={3} placeholder="How to give it, duration, and any precautions" /></label>
          </> : <>
            <label>Clinic service<select value={followUpServiceId} onChange={(event) => setFollowUpServiceId(event.target.value)} required>
              {enabledFollowUpServices.map((service) => <option key={service.id} value={service.id}>{service.name}</option>)}
            </select></label>
            <label>Revisit date<input type="date" value={followUpDate} min={manilaDate()} max={manilaDate(90)} onChange={(event) => setFollowUpDate(event.target.value)} required /></label>
            <label>Available time<select value={followUpTime} onChange={(event) => setFollowUpTime(event.target.value)} required disabled={followUpTimesLoading || followUpTimes.length === 0}>
              <option value="">{followUpTimesLoading ? 'Loading times…' : followUpTimes.length ? 'Choose a time' : 'No available times'}</option>
              {followUpTimes.map((time) => <option key={time} value={time}>{new Date(`2000-01-01T${time}:00+08:00`).toLocaleTimeString('en-PH', { timeZone: 'Asia/Manila', hour: 'numeric', minute: '2-digit' })}</option>)}
            </select></label>
            {followUpTimesError && <p className={`${styles.error} ${styles.wideField}`} role="alert">{followUpTimesError}</p>}
            <p className={`${styles.muted} ${styles.wideField}`}>The pet owner will receive a pending revisit request to confirm. The time is checked against the veterinarian’s live availability.</p>
          </>}
          {followUpFormError && <p className={`${styles.error} ${styles.wideField}`} role="alert">{followUpFormError}</p>}
          <div className={styles.formActions}>
            <button type="button" className={styles.secondaryButton} onClick={() => setFollowUpFormOpen(false)}>Cancel</button>
            <button type="submit" className={styles.primaryButton} disabled={state.saving || (followUpType === 'revisit' && (!followUpTime || followUpTimesLoading || enabledFollowUpServices.length === 0))}>{state.saving ? 'Saving…' : followUpType === 'medicine' ? 'Share medicine plan' : 'Send revisit request'}</button>
          </div>
        </form>}
        <div className={styles.metrics}>
          <article><span>Open follow-ups</span><b>{followUpRows.length}</b><small>Saved clinical plans</small></article>
          <article><span>Overdue</span><b>{state.followUps.filter((item) => item.followUpAt && item.followUpAt.slice(0, 10) < todayManila).length}</b><small>Needs action now</small></article>
          <article><span>Due soon</span><b>{state.followUps.filter((item) => item.followUpAt && item.followUpAt.slice(0, 10) >= todayManila && item.followUpAt.slice(0, 10) <= weekManila).length}</b><small>Next 7 days</small></article>
          <article><span>Owner revisit requests</span><b>{state.followUps.filter((item) => item.appointmentStatus === 'pending').length}</b><small>Waiting for owner response</small></article>
          <article><span>Appointments loaded</span><b>{appointments.length}</b><small>From the clinic schedule</small></article>
        </div>
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search by pet or owner..." /></div>
        <FilterButtons values={FOLLOW_UP_FILTERS} selected={state.filters['follow-up']} onSelect={(value) => dispatch({ type: 'SET_FILTER', key: 'follow-up', value })} />
        <div className={styles.tableWrap}><table className={styles.table}>
          <thead><tr><th>Patient</th><th>Plan and medicine</th><th>Clinical record date</th><th>Due date</th><th>Status</th><th>Actions</th></tr></thead>
          <tbody>{followUpRows.map((item) => <tr key={item.id}>
            <td><button type="button" className={styles.patientLink} onClick={() => onOpenPatient(item.petId)}><b>{item.patient}</b><small>{item.owner}</small></button></td>
            <td className={styles.summaryCell}><b>{item.reason}</b>{item.followUpType === 'medicine' && <small>{item.medicineName} · {item.medicineDose}</small>}{item.followUpType === 'medicine' && <small>{item.medicineInstructions}</small>}</td><td>{item.recordDate}</td><td><b>{item.due}</b></td><td><Status>{item.status}</Status></td>
            <td><div className={styles.rowActions}>
              {item.followUpType === 'revisit' && <button type="button" className={styles.softButton} onClick={() => onNavigate('calendar')}>View calendar</button>}
              <button type="button" className={styles.textButton} onClick={() => onNavigate('appointments')}>Appointments</button>
              <button type="button" className={styles.textButton} disabled={state.saving || item.appointmentStatus === 'pending'} onClick={() => void completeFollowUp(item.id)}>{item.appointmentStatus === 'pending' ? 'Awaiting owner' : 'Mark complete'}</button>
            </div></td>
          </tr>)}{followUpRows.length === 0 && <tr><td colSpan={6} className={styles.empty}>No follow-ups match this filter.</td></tr>}</tbody>
        </table></div>
      </>}

      {view === 'inbox' && <div className={styles.inbox}>
        <aside className={styles.threads}>
          <div className={styles.sectionHeading}><div><h2>Conversations</h2><p>{state.conversations.length} saved threads</p></div><button type="button" className={styles.textButton} onClick={() => dispatch({ type: 'TOGGLE_CONVERSATION_FORM' })}>＋ New</button></div>
          <SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search conversations..." />
          {state.conversationFormOpen && <form className={styles.newConversation} onSubmit={(event) => void startConversation(event)}>
            <label>Patient<select name="petId" required defaultValue=""><option value="" disabled>Choose an assigned patient</option>{patients.map((patient) => <option value={patient.id} key={patient.id}>{patient.name} · {patient.owner}</option>)}</select></label>
            <textarea name="body" required maxLength={2000} placeholder="Write your message..." />
            <button type="submit" className={styles.primaryButton} disabled={state.saving}>{state.saving ? 'Sending…' : 'Start conversation'}</button>
          </form>}
          {conversations.map((conversation) => <button type="button" className={`${styles.thread} ${state.selectedConversationId === conversation.id ? styles.threadActive : ''}`} key={conversation.id} onClick={() => void selectConversation(conversation.id)}>
            <span className={styles.threadAvatar}>{conversation.ownerName.split(' ').map((part) => part[0]).join('')}</span><span className={styles.threadCopy}><b>{conversation.ownerName} · {conversation.petName}</b><small>{conversation.latestMessage ?? 'No messages yet'}</small></span><small>{conversation.latestMessageAt ? new Date(conversation.latestMessageAt).toLocaleDateString() : ''}</small>{conversation.unreadCount > 0 && <i>{conversation.unreadCount}</i>}
          </button>)}
        </aside>
        <section className={styles.conversation}>
          {selectedConversation ? <>
            <header className={styles.conversationHeader}><span className={styles.threadAvatar}>{selectedConversation.ownerName.split(' ').map((part) => part[0]).join('')}</span><div><b>{selectedConversation.ownerName}</b><small>Pet owner · {selectedConversation.petName}</small></div></header>
            <div className={styles.messages}>{state.messages.map((message) => <p className={message.senderId === state.profile?.id ? styles.outgoing : styles.incoming} key={message.id}>{message.body}</p>)}</div>
          </> : <p className={styles.empty}>Select a conversation or start a new one.</p>}
          <form className={styles.composer} onSubmit={(event) => void sendMessage(event)}>
            <textarea value={state.draft} onChange={(event) => dispatch({ type: 'SET_DRAFT', value: event.target.value })} placeholder="Write a message..." aria-label="Write a message" />
            <button type="submit" className={styles.primaryButton} disabled={!state.selectedConversationId || !state.draft.trim() || state.saving}>{state.saving ? 'Sending…' : 'Send'}</button>
          </form>
        </section>
      </div>}

      {view === 'services' && <>
        <div className={styles.metrics}>
          <article><span>Services listed</span><b>{SERVICES.length}</b><small>From the booking catalog</small></article>
          <article><span>Preventive care</span><b>{SERVICES.filter((service) => service.category === 'preventive').length}</b><small>Available categories</small></article>
          <article><span>Treatment</span><b>{SERVICES.filter((service) => service.category === 'treatment').length}</b><small>Available categories</small></article>
          <article><span>Comfort &amp; care</span><b>{SERVICES.filter((service) => service.category === 'comfort').length}</b><small>Available categories</small></article>
        </div>
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search services..." /></div>
        <FilterButtons values={['All', 'preventive', 'treatment', 'comfort']} selected={state.filters.service} onSelect={(value) => dispatch({ type: 'SET_FILTER', key: 'service', value })} />
        <div className={styles.serviceGrid}>{visibleServices.map((service: Service) => {
          const isAvailable = state.serviceAvailability[service.id] ?? true;
          return <article className={styles.serviceCard} key={service.id}>
            <div className={styles.serviceTop}><span className={styles.serviceEmoji}>{service.emoji}</span><Status>{isAvailable ? 'Available' : 'Paused'}</Status></div>
            <h2>{service.name}</h2><p>{service.blurb}</p>
            <div className={styles.serviceMeta}><b>{formatPeso(service.price)}</b><span>{service.duration}</span></div>
            <button type="button" className={styles.softButton} disabled={state.saving} onClick={() => void toggleService(service.id)}>{isAvailable ? 'Pause booking' : 'Resume booking'}</button>
          </article>;
        })}{visibleServices.length === 0 && <p className={styles.empty}>No services match this search.</p>}</div>
      </>}

      {view === 'inventory' && <>
        <div className={styles.metrics}>
          <article><span>Products listed</span><b>{PRODUCTS.length}</b><small>Shop catalog</small></article>
          <article><span>Low stock</span><b>{Object.values(state.stockLevels).filter((quantity) => quantity < 5).length}</b><small>Below 5 units</small></article>
          <article><span>Out of stock</span><b>{PRODUCTS.filter((product) => state.stockLevels[product.id] === 0).length}</b><small>Needs replenishment</small></article>
          <article><span>Tracked products</span><b>{state.inventory.length}</b><small>Stock saved in database</small></article>
        </div>
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search products..." /></div>
        <div className={styles.tableWrap}><table className={styles.table}>
          <thead><tr><th>Product</th><th>Category</th><th>Unit price</th><th>Stock</th><th>Level</th><th>Set stock</th></tr></thead>
          <tbody>{visibleProducts.map((product: Product) => {
            const quantity = state.stockLevels[product.id];
            const level = quantity === undefined ? 'Not tracked' : quantity === 0 ? 'Out of stock' : quantity < 5 ? 'Low stock' : 'In stock';
            return <tr key={product.id}>
              <td><span className={styles.productCell}><span className={styles.serviceEmoji}>{product.emoji}</span><b>{product.name}</b></span></td><td>{product.category}</td><td>{formatPeso(product.price)}</td><td><b>{quantity ?? '—'}</b></td><td><Status>{level}</Status></td>
              <td><div className={styles.stockEditor}>
                <input
                  type="number"
                  aria-label={`${product.name} stock quantity`}
                  min={0}
                  max={1_000_000}
                  step={1}
                  value={state.stockDrafts[product.id] ?? String(quantity ?? 0)}
                  onChange={(event) => dispatch({ type: 'SET_STOCK_DRAFT', productId: product.id, value: event.target.value })}
                />
                <button type="button" className={styles.softButton} disabled={state.saving || !state.stockDirty[product.id]} onClick={() => void saveStock(product.id)}>Save</button>
              </div></td>
            </tr>;
          })}{visibleProducts.length === 0 && <tr><td colSpan={6} className={styles.empty}>No products match this search.</td></tr>}</tbody>
        </table></div>
      </>}

      {view === 'orders' && <>
        <div className={styles.metrics}>
          <article><span>Orders</span><b>{state.orders.length}</b><small>Saved orders</small></article>
          <article><span>Pending</span><b>{state.orders.filter((order) => order.status === 'pending').length}</b><small>Awaiting confirmation</small></article>
          <article><span>In progress</span><b>{state.orders.filter((order) => ['confirmed', 'preparing', 'ready_for_pickup', 'out_for_delivery'].includes(order.status)).length}</b><small>Being fulfilled</small></article>
          <article><span>Completed</span><b>{state.orders.filter((order) => order.status === 'completed').length}</b><small>Fulfilled orders</small></article>
        </div>
        <div className={styles.toolbar}><SearchBox value={state.query} onChange={(value) => dispatch({ type: 'SET_QUERY', value })} placeholder="Search by order number or customer..." /></div>
        <FilterButtons values={ORDER_FILTERS} selected={state.filters.order} onSelect={(value) => dispatch({ type: 'SET_FILTER', key: 'order', value })} />
        <div className={styles.tableWrap}><table className={styles.table}>
          <thead><tr><th>Order</th><th>Customer</th><th>Items</th><th>Fulfillment</th><th>Total</th><th>Payment</th><th>Status</th></tr></thead>
          <tbody>{visibleOrders.map((order) => {
            const nextStatuses: StaffOrder['status'][] = order.status === 'pending'
              ? ['confirmed', 'cancelled']
              : order.status === 'confirmed'
                ? ['preparing', 'cancelled']
              : order.status === 'preparing'
                ? order.fulfillmentMethod === 'delivery' ? ['out_for_delivery', 'cancelled'] : ['ready_for_pickup', 'cancelled']
                : order.status === 'ready_for_pickup' || order.status === 'out_for_delivery' ? ['completed'] : [];
            return <tr key={order.id}>
              <td><b>#{order.id}</b></td>
              <td>{order.customerName}<small>{order.contactPhone}</small></td>
              <td className={styles.summaryCell}>{order.items.map((item) => `${item.quantity} × ${item.productName}`).join(', ')}</td>
              <td className={styles.summaryCell}>{order.fulfillmentMethod === 'delivery' ? `Delivery · ${order.deliveryAddress}` : 'Clinic pickup'}</td>
              <td><b>{formatPeso(Number(order.totalAmount))}</b></td>
              <td>{order.paymentMethod.replaceAll('_', ' ')}</td>
              <td>
                <select
                  className={styles.orderStatusSelect}
                  aria-label={`Update order ${order.id} status`}
                  value={order.status}
                  disabled={state.saving || nextStatuses.length === 0}
                  onChange={(event) => {
                    if (isOrderStatus(event.target.value)) void updateOrder(order.id, event.target.value);
                  }}
                >
                  <option value={order.status}>{orderStatusLabel(order.status)}</option>
                  {nextStatuses.map((status) => <option key={status} value={status}>{orderStatusLabel(status)}</option>)}
                </select>
              </td>
            </tr>;
          })}{visibleOrders.length === 0 && <tr><td colSpan={7} className={styles.empty}>No saved orders match this filter.</td></tr>}</tbody>
        </table></div>
      </>}

      {view === 'profile' && <div className={styles.profileGrid}>
        <article className={styles.profileCard}>
          <div className={styles.profileIdentity}><span className={styles.profileAvatar}>🩺</span><div><h2>{doctorName}</h2><p>Veterinarian</p></div></div>
          <label className={styles.fieldLabel}>Display name<input value={state.profileName} maxLength={120} required onChange={(event) => dispatch({ type: 'SET_PROFILE_NAME', value: event.target.value })} /></label>
          <label className={styles.fieldLabel}>Phone<input value={state.profilePhone} maxLength={32} onChange={(event) => dispatch({ type: 'SET_PROFILE_PHONE', value: event.target.value })} /></label>
          <label className={styles.fieldLabel}>Email<input value={state.profile?.email ?? ''} readOnly /></label>
          <label className={styles.fieldLabel}>Specialization<input value={state.profile?.specialization ?? 'Not provided'} readOnly /></label>
          <label className={styles.fieldLabel}>Account role<input value="Veterinarian" readOnly /></label>
          <button type="button" className={styles.primaryButton} disabled={state.saving} onClick={() => void saveProfile()}>{state.saving ? 'Saving…' : 'Save profile'}</button>
        </article>
        <article className={styles.profileCard}><h2>Account access</h2><p className={styles.description}>Your clinic account and sign-in permissions are managed by the clinic administrator.</p><button type="button" className={styles.softButton} onClick={() => onNavigate('appointments')}>Review appointments</button></article>
      </div>}

      {view === 'availability' && <>
        <article className={styles.availabilityCard}>
          <div className={styles.sectionHeading}><div><h2>Weekly doctor availability</h2><p>Set the recurring days and hours saved to your account.</p></div><Status>{state.availabilityDirty ? 'Unsaved changes' : 'Saved'}</Status></div>
          <div className={styles.timeRange}><label className={styles.fieldLabel}>Opens<input type="time" value={state.startTime} onChange={(event) => dispatch({ type: 'SET_START_TIME', value: event.target.value })} /></label><span>to</span><label className={styles.fieldLabel}>Closes<input type="time" value={state.endTime} onChange={(event) => dispatch({ type: 'SET_END_TIME', value: event.target.value })} /></label></div>
          <div className={styles.weekdays}>{WEEKDAYS.map((day, index) => { const weekday = String(WEEKDAY_NUMBERS[index]); const isAvailable = state.activeDays[weekday] ?? false; return <label className={styles.weekday} key={day}><span>{day}</span><input type="checkbox" checked={isAvailable} onChange={() => dispatch({ type: 'TOGGLE_DAY', day: weekday })} /><small>{isAvailable ? 'Available' : 'Unavailable'}</small></label>; })}</div>
          <button type="button" className={styles.primaryButton} disabled={state.saving} onClick={() => void saveAvailability()}>{state.saving ? 'Saving…' : 'Save availability'}</button>
        </article>
        <p className={styles.muted}>Owners see these saved hours when choosing a veterinarian. Their booking times refresh automatically about every 30 seconds.</p>
      </>}

      {view === 'settings' && <article className={styles.settingsCard}>
        <div className={styles.sectionHeading}><div><h2>Notifications</h2><p>Choose which reminders appear in this workspace.</p></div></div>
        {([
          ['appointmentRequests', 'Appointment requests', 'New booking requests that need a response.'],
          ['followUpReminders', 'Follow-up reminders', 'Upcoming and overdue patient rechecks.'],
          ['labResults', 'Laboratory results', 'New results ready for doctor review.'],
          ['inventoryAlerts', 'Inventory alerts', 'Low-stock product notifications.'],
        ] as const).map(([key, label, description]) => <label className={styles.settingRow} key={key}><span><b>{label}</b><small>{description}</small></span><input type="checkbox" checked={state.notificationSettings[key] ?? false} onChange={() => dispatch({ type: 'TOGGLE_SETTING', key })} /></label>)}
        <button type="button" className={styles.primaryButton} disabled={state.saving} onClick={() => void savePreferences()}>{state.saving ? 'Saving…' : 'Save settings'}</button>
      </article>}
    </section>
  );
}